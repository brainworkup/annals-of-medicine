# Extracted Figures from ADHD Adults Diagnosis Report

All figures have been successfully extracted from the Word document and saved as PNG files in the `/mnt/user-data/outputs/figures/` directory.

## List of Extracted Figures

1. **Figure_1_Logic_Model.png**
   - Title: Logic Model for Diagnosis of ADHD in Adults
   - Dimensions: 1076 × 556 pixels
   - File size: 91,475 bytes
   - Original format: PNG

2. **Figure_2_Literature_Flow_Diagram.png**
   - Title: Literature Flow Diagram showing study selection process
   - Dimensions: 1634 × 546 pixels
   - File size: 14,693 bytes
   - Original format: PNG

3. **Figure_3_Risk_of_Bias.png**
   - Title: Risk of Bias assessment across studies
   - Dimensions: 2500 × 1053 pixels
   - File size: 35,112 bytes
   - Original format: PNG

4. **Figure_4_Applicability_to_Practice.png**
   - Title: Applicability to Routine Practice of Reported Results
   - Dimensions: 794 × 1123 pixels
   - File size: 52,000 bytes
   - Original format: EMF (converted to PNG)

5. **Figure_5_Self_Report_Sensitivity_Specificity.png**
   - Title: Reported Sensitivity and Specificity of ADHD Self-Report Questionnaires in Adults Across Studies
   - Dimensions: 794 × 1123 pixels
   - File size: 39,601 bytes
   - Original format: EMF (converted to PNG)

6. **Figure_6_Neuropsych_Tests_Sensitivity_Specificity.png**
   - Title: Reported Sensitivity and Specificity of Neuropsychological Tests for ADHD in Adults across Studies
   - Dimensions: 794 × 1123 pixels
   - File size: 39,876 bytes
   - Original format: EMF (converted to PNG)

7. **Figure_7_Accuracy_and_AUC.png**
   - Title: Reported Accuracy and Area Under the Curve (AUC) Across Tools
   - Dimensions: 794 × 1123 pixels
   - File size: 48,219 bytes
   - Original format: EMF (converted to PNG)

## Note on Figure 8

The document references Figure 8 (Sensitivity and Specificity of ADHD Tests in Adults across Studies), but only 7 image files were found in the Word document. It's possible that:
- Figure 8 may be created from data rather than embedded as an image
- Figure 8 may be combined with another figure
- Figure 8 may be missing from this draft version

## Technical Details

- **Extraction Method**: Word document was unpacked as a ZIP archive to access embedded media files
- **Conversion Tool**: LibreOffice was used to convert EMF (Enhanced Metafile) format images to PNG
- **Total Figures Extracted**: 7 figures
- **Total Size**: Approximately 321 KB for all figures combined

All figures are now ready for use in your manuscript preparation for Annals of Internal Medicine.
